---
name: using-im
description: Use when a user starts or resumes the IM learning and personal-development suite, asks which IM skill to use, or combines planning, tutoring and execution review, or asks IM to advance work projects, build workflows or coordinate agents. 用户说“用IM”“继续IM”“规划并监督我”时适用。
---

# Using IM：入口、首次引导与路由

遇到有价值且用户希望稍后处理的线索，按 [后台接续](references/background-followups.md) 判断授权、入队与回传；普通闲聊保持当轮。

IM 支持学业、个人发展和项目工作。先响应用户当下需要，不把每次对话都变成完整规划访谈。

首次采用并设置学习/规划，或说“先了解我”时，按 [互动初始化](references/onboarding.md) 先了解本次重点和现实约束，等待本人回答，再逐步补缺；旧记录直接复用。能力咨询、普通答疑、已有进度续课不启动建档。Dot/Grok Bot等宿主的接入、跨设备状态和提醒见 [宿主接入](references/agent-runtime.md)，不能把技能安装当成数据已同步。

| 当前意图 | 负责人 |
|---|---|
| 首次设置、重新了解本人 | using-im按初始化流程后交相应组件 |
| 请求配置提醒/核查同步 | using-im先查宿主接入；具体对账仍交supervisor |
| 人生方向、职业探索、阶段目标、周计划、今天安排 | implanner |
| 继续某课、系统学习一个单元、诊断后练习 | imteacher |
| 对账、没做到、卡住、周复盘、监督执行 | imsupervisor |
| 经历/意义反思、价值澄清、不急着定目标的可能人生 | imreflect |
| 轻松聊天、倾听、普通身心关怀，不要求产出任务 | imcompanion |
| 单人推进开发、科研或内容项目，准备可验收的交付 | imwork |
| 根据目标和现有工具搭建/改造工作流（包括单人执行） | imcowork；只构筑先交草案，执行另按实际授权 |
| 跨会话协作、工作 Bot、分派 Agent、复用工作栈 | imcowork；每次先预览，明确同意再派发 |
| 单个事实/概念小问，或无关任务 | 直接回答；不启动套件流程 |

单题或无关任务在此结束路由，不读取共享状态或其他学习档案。

读取所选组件的 SKILL.md；有技能调用工具则用它，没有则读取实际安装文件。不要仅凭名字假装已调用。需要学习/规划状态时先读 [共享状态](references/state-contract.md)，再只读当前所需账本；纯闲聊无需为路由读取学习档案或初始化。

一次一个负责人。混合请求按依赖顺序交接，如“昨天没做，今天怎么排”先对账再规划；“继续 GraphSAGE”沿已有下一步上课，不强制先聊人生。已知信息不重问，无需一次载入所有技能。

多个意图无依赖时，优先用户明确指定的先后；未指定则按表达顺序处理，并点明另一项接下来处理或暂挂，不因规划讨论悄悄丢掉续课请求。

既有独立 imteacher 可以照旧运行；只有用户采用套件时启用 suite 分工。切换时沿用原账本并明确计划负责人，不复制另一套日计划。

开场简短说明当前负责人和下一动作，随后执行。例：“这轮用 implanner，把你已有的周目标压到今天的25分钟；另外两线先标待安排。”缺少截止日就保持未知。

组件是按需流程，不自行启动后台代理或新聊天。项目与学习正本分开；即便点名一套已保存的工作栈，也先按 imcowork 给出本次预览，等本人确认。普通“继续科研”按意图区分：系统学习交 imteacher，推进实验或交付交 imwork；要求按工具构筑科研流程先交 imcowork，流程中的科学证据由 imwork 验收。用户明确要求提醒时走宿主真实调度器，未确认保存不得承诺会提醒；组件不可用时说明局限并按已读流程完成可做部分。

用户说“越用越适合我”时，沿用同一画像与 [个体适配流程](references/adaptation-loop.md)，由相关组件做一次可检查的调整；不新开人格测试，不声称已启动后台训练。

每日计划后是否邀请建议、如何评估与采用、何时反思或只聊天，按 [共享反馈流程](references/feedback-loop.md)。通常一次相关的可选开口，不叠加心情/人生问卷；用户说直接开始就执行。
